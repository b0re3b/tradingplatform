from __future__ import annotations

from analytics.strategy_contract import ensure_strategy_payload_contract
import hashlib
import inspect
import time
from collections import deque
from datetime import datetime, timedelta
from decimal import Decimal
from typing import Any, Protocol, runtime_checkable

from core.event_bus import Event, EventBus, EventPriority, Subscription
from core.logger import get_logger
from core.scheduler import Scheduler

from analytics.liquidations.config import LiquidationStreamConfig
from analytics.liquidations.enums import LiquidationEventType, LiquidationSide
from analytics.liquidations.metrics import LiquidationMetrics
from analytics.liquidations.models import (
    DEFAULT_MARKET_TYPE,
    DEFAULT_TIMEFRAME,
    LiquidationEvent,
    LiquidationKey,
    liquidation_key_to_dict,
    make_liquidation_key,
    normalize_exchange,
    normalize_exchange_symbol,
    normalize_market_type,
    normalize_symbol,
    normalize_timeframe,
)
from .state import LiquidationState, get_shared_liquidation_state
from .utils import (
    ensure_utc,
    is_stale_event,
    safe_decimal,
    scoped_key_to_string,
    utc_now,
)


@runtime_checkable
class LiquidationHistoryStoreProtocol(Protocol):
    """
    Optional storage hook for normalized liquidation history.

    Production implementation should live outside analytics, for example in:
        storage/liquidation_parquet_store.py

    LiquidationStream only calls this protocol and does not know whether the
    backend is parquet, database, Redis, or in-memory.
    """

    async def append_event(self, event: LiquidationEvent) -> None:
        ...

    async def append_large_event(self, event: LiquidationEvent) -> None:
        ...

    async def flush(self) -> None:
        ...


class LiquidationStream:
    """
    State-driven liquidation analytics stream.

    Correct production flow:
        exchange adapters
            -> MarketIngestionService.ingest_liquidation(...)
            -> MarketStateStore
            -> LiquidationStream.process_market_state_snapshot(...)
            -> LiquidationEvent
            -> shared LiquidationState / LiquidationMetrics
            -> analytics/normalized liquidation output events
            -> CascadeDetector / strategy context

    Backward compatibility:
        If market_state_store is not injected, the class can still subscribe to
        legacy raw EventBus topics.  In the new production path, raw
        market.liquidation is NOT used as the primary input.

    Responsibilities:
    - read liquidation windows from MarketStateStore snapshots;
    - accept data from many exchanges without scope conflicts;
    - normalize snapshot liquidation items into LiquidationEvent;
    - filter invalid/stale/duplicate events;
    - update shared LiquidationState using LiquidationKey;
    - update LiquidationMetrics;
    - optionally append normalized events to injected history store;
    - publish normalized / large / updated analytics events;
    - register health/snapshot/cleanup jobs through core.Scheduler.

    Scope:
        exchange + market_type + symbol + timeframe

    This class intentionally does NOT connect to exchange WebSockets directly.
    Exchange adapters publish raw liquidation payloads to EventBus, for example:
        BybitWS -> emit("market.liquidation", payload)

    This stream is the data/cache layer between exchange adapters and analytics
    detectors.
    """

    DEFAULT_INPUT_TOPIC = "market.liquidation"
    DEFAULT_UPDATED_TOPIC = "market.liquidations.updated"

    def __init__(
        self,
        *,
        event_bus: EventBus,
        config: LiquidationStreamConfig,
        scheduler: Scheduler | None = None,
        state: LiquidationState | None = None,
        metrics: LiquidationMetrics | None = None,
        history_store: LiquidationHistoryStoreProtocol | None = None,
        market_state_store: Any | None = None,
        service_name: str = "liquidation_stream",
    ) -> None:
        try:
            _analytics_logger = getattr(self, "logger", None) or getattr(self, "_logger", None)
            if _analytics_logger is None:
                _analytics_logger = get_logger(f"{__name__}.{self.__class__.__name__}")
                self.logger = _analytics_logger
            _analytics_class_name = self.__class__.__name__
            _analytics_args = {
                _k: (
                    {"type": "dict", "size": len(_v), "keys": [str(_key) for _key in list(_v.keys())[:20]]}
                    if isinstance(_v, dict)
                    else {"type": type(_v).__name__, "size": len(_v)}
                    if isinstance(_v, (list, tuple, set, frozenset))
                    else {"type": type(_v).__name__}
                )
                for _k, _v in locals().items()
                if _k not in {"self", "cls", "_analytics_logger", "_analytics_class_name", "_analytics_args"}
                and not _k.startswith("_analytics")
            }
            _analytics_logger.debug("%s.%s entered | args=%s", _analytics_class_name, "__init__", _analytics_args)
        except Exception:
            pass
        self.event_bus = event_bus
        self.scheduler = scheduler
        self.config = config
        self.config.validate()
        self.service_name = service_name
        self.history_store = history_store
        self.market_state_store = market_state_store

        self.state = state or get_shared_liquidation_state(
            max_events_per_symbol=self.config.max_buffer_size_per_symbol,
        )
        self.metrics = metrics or LiquidationMetrics()

        self.input_topic = str(
            getattr(self.config, "input_topic_raw", None)
            or getattr(self.config, "input_topic", None)
            or self.DEFAULT_INPUT_TOPIC
        )
        self.publish_topic_updated = str(
            getattr(self.config, "publish_topic_updated", None)
            or self.DEFAULT_UPDATED_TOPIC
        )

        self.logger = get_logger(
            __name__,
            service_name=self.service_name,
            event_type="analytics.liquidations.stream",
        )

        if state is None:
            self.logger.info(
                "LiquidationStream using package-level shared LiquidationState"
            )

        self._running = False
        self._registered = False
        self._closed = False
        self._subscriptions: list[Subscription] = []

        self._started_at: datetime | None = None
        self._stopped_at: datetime | None = None
        self._last_message_at: datetime | None = None
        self._last_event_at: datetime | None = None
        self._last_error_at: datetime | None = None
        self._last_error: str | None = None

        self._processed_messages = 0
        self._processed_events = 0
        self._dropped_invalid = 0
        self._dropped_stale = 0
        self._dropped_duplicates = 0
        self._filtered_scope = 0
        self._storage_errors = 0

        self._published_raw = 0
        self._published_normalized = 0
        self._published_large = 0
        self._published_updated = 0
        self._published_health = 0
        self._published_snapshots = 0

        self._recent_payload_fingerprints: deque[str] = deque(
            maxlen=max(1, self.config.recent_payload_fingerprints_size),
        )
        self._recent_payload_fingerprint_set: set[str] = set()

        self._recent_large_events: deque[LiquidationEvent] = deque(
            maxlen=max(1, self.config.recent_large_events_size),
        )

        self._processed_snapshot_scopes = 0
        self._processed_snapshot_liquidations = 0
        self._state_input_mode = self.market_state_store is not None

        self._healthcheck_job_id: str | None = None
        self._snapshot_job_id: str | None = None
        self._cleanup_job_id: str | None = None

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def register(self) -> None:
        """Register EventBus subscriptions and Scheduler jobs."""
        try:
            _analytics_logger = getattr(self, "logger", None) or getattr(self, "_logger", None)
            if _analytics_logger is None:
                _analytics_logger = get_logger(f"{__name__}.{self.__class__.__name__}")
                self.logger = _analytics_logger
            _analytics_class_name = self.__class__.__name__
            _analytics_args = {
                _k: (
                    {"type": "dict", "size": len(_v), "keys": [str(_key) for _key in list(_v.keys())[:20]]}
                    if isinstance(_v, dict)
                    else {"type": type(_v).__name__, "size": len(_v)}
                    if isinstance(_v, (list, tuple, set, frozenset))
                    else {"type": type(_v).__name__}
                )
                for _k, _v in locals().items()
                if _k not in {"self", "cls", "_analytics_logger", "_analytics_class_name", "_analytics_args"}
                and not _k.startswith("_analytics")
            }
            _analytics_logger.debug("%s.%s entered | args=%s", _analytics_class_name, "register", _analytics_args)
        except Exception:
            pass
        if self._registered:
            self.logger.warning("LiquidationStream already registered")
            return

        if self._closed:
            raise RuntimeError("Cannot register closed LiquidationStream")

        if not self.config.enabled:
            self.logger.info("LiquidationStream registration skipped: disabled by config")
            return

        if self.market_state_store is None:
            for topic in self.config.input_topics:
                self.config.assert_input_topic_allowed(topic)
                self._subscriptions.append(
                    self.event_bus.subscribe(
                        topic,
                        self.on_raw_liquidation,
                        name=f"{self.service_name}.on_raw_liquidation",
                    )
                )
        else:
            self.logger.info(
                "LiquidationStream registered in state-driven mode; raw EventBus liquidation subscriptions are disabled"
            )

        self._register_scheduler_jobs()
        self._registered = True

        self.logger.info(
            "LiquidationStream registered",
            extra={
                "input_topics": list(self.config.input_topics),
                "output_topics": list(self.config.output_topics),
                "scheduler_enabled": self.scheduler is not None,
                "scope": "exchange:market_type:symbol:timeframe",
                "input_mode": "market_state" if self.market_state_store is not None else "event_bus_legacy",
            },
        )

    async def unregister(self) -> None:
        """Remove EventBus subscriptions and scheduler jobs."""
        try:
            _analytics_logger = getattr(self, "logger", None) or getattr(self, "_logger", None)
            if _analytics_logger is None:
                _analytics_logger = get_logger(f"{__name__}.{self.__class__.__name__}")
                self.logger = _analytics_logger
            _analytics_class_name = self.__class__.__name__
            _analytics_args = {
                _k: (
                    {"type": "dict", "size": len(_v), "keys": [str(_key) for _key in list(_v.keys())[:20]]}
                    if isinstance(_v, dict)
                    else {"type": type(_v).__name__, "size": len(_v)}
                    if isinstance(_v, (list, tuple, set, frozenset))
                    else {"type": type(_v).__name__}
                )
                for _k, _v in locals().items()
                if _k not in {"self", "cls", "_analytics_logger", "_analytics_class_name", "_analytics_args"}
                and not _k.startswith("_analytics")
            }
            _analytics_logger.debug("%s.%s entered | args=%s", _analytics_class_name, "unregister", _analytics_args)
        except Exception:
            pass
        if not self._registered:
            return

        for subscription in list(self._subscriptions):
            try:
                self.event_bus.unsubscribe(subscription)
            except Exception as exc:
                self.logger.warning(
                    "Failed to unsubscribe LiquidationStream subscription | error=%s",
                    repr(exc),
                    extra={
                        "subscription": repr(subscription),
                    },
                )

        self._subscriptions.clear()

        await self._remove_scheduler_jobs()
        self._registered = False

        self.logger.info("LiquidationStream unregistered")

    async def start(self) -> None:
        try:
            _analytics_logger = getattr(self, "logger", None) or getattr(self, "_logger", None)
            if _analytics_logger is None:
                _analytics_logger = get_logger(f"{__name__}.{self.__class__.__name__}")
                self.logger = _analytics_logger
            _analytics_class_name = self.__class__.__name__
            _analytics_args = {
                _k: (
                    {"type": "dict", "size": len(_v), "keys": [str(_key) for _key in list(_v.keys())[:20]]}
                    if isinstance(_v, dict)
                    else {"type": type(_v).__name__, "size": len(_v)}
                    if isinstance(_v, (list, tuple, set, frozenset))
                    else {"type": type(_v).__name__}
                )
                for _k, _v in locals().items()
                if _k not in {"self", "cls", "_analytics_logger", "_analytics_class_name", "_analytics_args"}
                and not _k.startswith("_analytics")
            }
            _analytics_logger.debug("%s.%s entered | args=%s", _analytics_class_name, "start", _analytics_args)
        except Exception:
            pass
        if self._closed:
            raise RuntimeError("Cannot start closed LiquidationStream")

        if self._running:
            self.logger.warning("LiquidationStream already running")
            return

        if not self.config.enabled:
            self.logger.warning("LiquidationStream is disabled by config")
            return

        if not self._registered:
            self.register()

        self._running = True
        self._started_at = utc_now()
        self._stopped_at = None
        self._last_error = None
        self._last_error_at = None

        self.logger.info(
            "LiquidationStream started",
            extra={
                "input_topics": list(self.config.input_topics),
                "symbols": list(self.config.symbols),
                "exchanges": list(self.config.exchanges),
                "market_types": list(self.config.market_types),
                "timeframes": list(self.config.timeframes),
                "scope": "exchange:market_type:symbol:timeframe",
            },
        )

    async def stop(self) -> None:
        try:
            _analytics_logger = getattr(self, "logger", None) or getattr(self, "_logger", None)
            if _analytics_logger is None:
                _analytics_logger = get_logger(f"{__name__}.{self.__class__.__name__}")
                self.logger = _analytics_logger
            _analytics_class_name = self.__class__.__name__
            _analytics_args = {
                _k: (
                    {"type": "dict", "size": len(_v), "keys": [str(_key) for _key in list(_v.keys())[:20]]}
                    if isinstance(_v, dict)
                    else {"type": type(_v).__name__, "size": len(_v)}
                    if isinstance(_v, (list, tuple, set, frozenset))
                    else {"type": type(_v).__name__}
                )
                for _k, _v in locals().items()
                if _k not in {"self", "cls", "_analytics_logger", "_analytics_class_name", "_analytics_args"}
                and not _k.startswith("_analytics")
            }
            _analytics_logger.debug("%s.%s entered | args=%s", _analytics_class_name, "stop", _analytics_args)
        except Exception:
            pass
        if not self._running:
            return

        self._running = False
        self._stopped_at = utc_now()

        if self.history_store is not None:
            await self._flush_history_store()

        self.logger.info("LiquidationStream stopped | stats=%s", self.get_stats())

    async def close(self) -> None:
        try:
            _analytics_logger = getattr(self, "logger", None) or getattr(self, "_logger", None)
            if _analytics_logger is None:
                _analytics_logger = get_logger(f"{__name__}.{self.__class__.__name__}")
                self.logger = _analytics_logger
            _analytics_class_name = self.__class__.__name__
            _analytics_args = {
                _k: (
                    {"type": "dict", "size": len(_v), "keys": [str(_key) for _key in list(_v.keys())[:20]]}
                    if isinstance(_v, dict)
                    else {"type": type(_v).__name__, "size": len(_v)}
                    if isinstance(_v, (list, tuple, set, frozenset))
                    else {"type": type(_v).__name__}
                )
                for _k, _v in locals().items()
                if _k not in {"self", "cls", "_analytics_logger", "_analytics_class_name", "_analytics_args"}
                and not _k.startswith("_analytics")
            }
            _analytics_logger.debug("%s.%s entered | args=%s", _analytics_class_name, "close", _analytics_args)
        except Exception:
            pass
        if self._closed:
            return

        await self.stop()
        await self.unregister()
        self._closed = True

        self.logger.info("LiquidationStream closed")

    async def restart(self) -> None:
        try:
            _analytics_logger = getattr(self, "logger", None) or getattr(self, "_logger", None)
            if _analytics_logger is None:
                _analytics_logger = get_logger(f"{__name__}.{self.__class__.__name__}")
                self.logger = _analytics_logger
            _analytics_class_name = self.__class__.__name__
            _analytics_args = {
                _k: (
                    {"type": "dict", "size": len(_v), "keys": [str(_key) for _key in list(_v.keys())[:20]]}
                    if isinstance(_v, dict)
                    else {"type": type(_v).__name__, "size": len(_v)}
                    if isinstance(_v, (list, tuple, set, frozenset))
                    else {"type": type(_v).__name__}
                )
                for _k, _v in locals().items()
                if _k not in {"self", "cls", "_analytics_logger", "_analytics_class_name", "_analytics_args"}
                and not _k.startswith("_analytics")
            }
            _analytics_logger.debug("%s.%s entered | args=%s", _analytics_class_name, "restart", _analytics_args)
        except Exception:
            pass
        await self.stop()
        await self.start()

    # ------------------------------------------------------------------
    # State-driven input API
    # ------------------------------------------------------------------

    async def process_dirty_state_scopes(self, *, limit: int | None = 500, depth: int | None = None) -> int:
        """Process dirty MarketStateStore snapshots that include liquidation changes.

        This is the preferred production entrypoint for MarketScheduler.  It does
        not consume raw EventBus market.liquidation events; it reads already
        ingested market state snapshots and publishes only analytics outputs.
        """
        if self.market_state_store is None:
            return 0

        snapshots_for_dirty = getattr(self.market_state_store, "snapshots_for_dirty", None)
        if not callable(snapshots_for_dirty):
            self.logger.warning("MarketStateStore has no snapshots_for_dirty() method")
            return 0

        snapshots = await snapshots_for_dirty(limit=limit, depth=depth)
        processed = 0
        for snapshot in snapshots:
            dirty_reasons = {str(reason).lower() for reason in (getattr(snapshot, "dirty_reasons", ()) or ())}
            if dirty_reasons and "liquidation" not in dirty_reasons:
                continue
            processed += await self.process_market_state_snapshot(snapshot=snapshot)
        return processed

    async def process_market_snapshot(self, snapshot: Any) -> int:
        """MarketScheduler-compatible state-driven entrypoint.

        MarketScheduler registers callbacks named process_market_snapshot().
        LiquidationStream already had process_market_state_snapshot(), but without
        this adapter it was easy for wiring code to skip liquidations entirely.
        """
        return await self.process_market_state_snapshot(snapshot=snapshot)

    async def process_market_state_snapshot(
        self,
        snapshot: Any | None = None,
        *,
        exchange: str | None = None,
        market_type: str | None = None,
        symbol: str | None = None,
        timeframe: str | None = None,
        depth: int | None = None,
    ) -> int:
        """Read liquidation items from MarketStateStore and update analytics state.

        Either pass an already built MarketSnapshot or pass scope fields so this
        method can request the snapshot from the injected MarketStateStore.
        Returns the number of newly accepted liquidation events.
        """
        if snapshot is None:
            if self.market_state_store is None:
                return 0
            if not symbol:
                raise ValueError("symbol is required when snapshot is not provided")
            from data.market_models import MarketScope

            scope = MarketScope(
                exchange=exchange or "binance",
                market_type=market_type or DEFAULT_MARKET_TYPE,
                symbol=symbol,
                timeframe=timeframe or DEFAULT_TIMEFRAME,
            )
            snapshot = await self.market_state_store.snapshot(scope, depth=depth)

        self._processed_snapshot_scopes += 1
        processed = 0
        for payload in self._liquidation_payloads_from_snapshot(snapshot):
            event = await self.handle_raw_message(payload)
            if event is not None:
                processed += 1
        self._processed_snapshot_liquidations += processed
        return processed

    def _liquidation_payloads_from_snapshot(self, snapshot: Any) -> list[dict[str, Any]]:
        scope = getattr(snapshot, "scope", None)
        exchange = getattr(scope, "exchange", None) or self.config.default_exchange if hasattr(self.config, "default_exchange") else None
        market_type = getattr(scope, "market_type", None) or DEFAULT_MARKET_TYPE
        symbol = getattr(scope, "symbol", None)
        timeframe = getattr(scope, "timeframe", None) or DEFAULT_TIMEFRAME
        exchange_symbol = getattr(scope, "exchange_symbol", None) or symbol

        # MarketSnapshot.current_price exists in the new data layer; keep a
        # fallback for dict-like snapshots or older test doubles.
        current_price = getattr(snapshot, "current_price", None)
        if current_price is None:
            current_price = getattr(snapshot, "last_price", None) or getattr(snapshot, "reference_price", None)

        items = list(getattr(snapshot, "liquidations", ()) or ())
        payloads: list[dict[str, Any]] = []
        for item in items:
            if hasattr(item, "to_dict") and callable(item.to_dict):
                item_dict = dict(item.to_dict())
            elif isinstance(item, dict):
                item_dict = dict(item)
            else:
                item_dict = {
                    "price": getattr(item, "price", None),
                    "quantity": getattr(item, "quantity", None),
                    "side": getattr(item, "side", None),
                    "timestamp_ms": getattr(item, "timestamp_ms", None),
                    "order_id": getattr(item, "order_id", None),
                    "metadata": dict(getattr(item, "metadata", {}) or {}),
                }

            metadata = dict(item_dict.get("metadata") or {})
            payload = {
                "exchange": metadata.get("exchange") or exchange,
                "market_type": metadata.get("market_type") or market_type,
                "symbol": metadata.get("symbol") or symbol,
                "timeframe": metadata.get("timeframe") or timeframe,
                "exchange_symbol": metadata.get("exchange_symbol") or exchange_symbol,
                "side": item_dict.get("side"),
                "price": item_dict.get("price"),
                "quantity": item_dict.get("quantity"),
                "order_id": item_dict.get("order_id") or metadata.get("order_id"),
                "trade_id": metadata.get("trade_id"),
                "event_id": metadata.get("event_id") or metadata.get("id"),
                "timestamp_ms": item_dict.get("timestamp_ms") or metadata.get("timestamp_ms"),
                "event_time": item_dict.get("timestamp_ms") or metadata.get("event_time"),
                "current_price": current_price or item_dict.get("price"),
                "reference_price": current_price or item_dict.get("price"),
                "source_topic": "market_state.liquidations",
                "source": "market_state_store",
                "metadata": {
                    **metadata,
                    "input_mode": "market_state_snapshot",
                    "snapshot_updated_at_ms": getattr(snapshot, "updated_at_ms", None),
                },
            }
            payloads.append(payload)
        return payloads

    # ------------------------------------------------------------------
    # EventBus input handler
    # ------------------------------------------------------------------

    async def on_raw_liquidation(self, event: Event) -> None:
        """
        Consume raw liquidation payloads from exchange adapters.

        Expected topic:
            market.liquidation

        Payload must be a dict containing at least:
            exchange, symbol, side, price, quantity/qty, timestamp-like field

        Optional but recommended:
            market_type, timeframe, exchange_symbol

        Handler is multi-exchange/futures safe because every normalized event
        carries:
            exchange + market_type + symbol + timeframe
        """
        try:
            _analytics_logger = getattr(self, "logger", None) or getattr(self, "_logger", None)
            if _analytics_logger is None:
                _analytics_logger = get_logger(f"{__name__}.{self.__class__.__name__}")
                self.logger = _analytics_logger
            _analytics_class_name = self.__class__.__name__
            _analytics_args = {
                _k: (
                    {"type": "dict", "size": len(_v), "keys": [str(_key) for _key in list(_v.keys())[:20]]}
                    if isinstance(_v, dict)
                    else {"type": type(_v).__name__, "size": len(_v)}
                    if isinstance(_v, (list, tuple, set, frozenset))
                    else {"type": type(_v).__name__}
                )
                for _k, _v in locals().items()
                if _k not in {"self", "cls", "_analytics_logger", "_analytics_class_name", "_analytics_args"}
                and not _k.startswith("_analytics")
            }
            _analytics_logger.debug("%s.%s entered | args=%s", _analytics_class_name, "on_raw_liquidation", _analytics_args)
        except Exception:
            pass
        if not self._running:
            return

        started = time.perf_counter()
        payload = event.payload
        self._processed_messages += 1
        self._last_message_at = utc_now()

        if not isinstance(payload, dict):
            self._dropped_invalid += 1
            self.metrics.observe_invalid_event()
            self.logger.debug(
                "Non-dict liquidation payload dropped | topic=%s payload_type=%s",
                event.topic,
                type(payload).__name__,
            )
            return

        enriched_payload = dict(payload)
        enriched_payload.setdefault("correlation_id", event.correlation_id)
        enriched_payload.setdefault("source_topic", event.topic)

        try:
            await self.handle_raw_message(enriched_payload)
        finally:
            self.metrics.observe_latency_ms((time.perf_counter() - started) * 1000.0)

    async def handle_raw_message(self, payload: dict[str, Any]) -> LiquidationEvent | None:
        """
        Normalize, validate, deduplicate, store, and publish a raw liquidation payload.
        """
        try:
            _analytics_logger = getattr(self, "logger", None) or getattr(self, "_logger", None)
            if _analytics_logger is None:
                _analytics_logger = get_logger(f"{__name__}.{self.__class__.__name__}")
                self.logger = _analytics_logger
            _analytics_class_name = self.__class__.__name__
            _analytics_args = {
                _k: (
                    {"type": "dict", "size": len(_v), "keys": [str(_key) for _key in list(_v.keys())[:20]]}
                    if isinstance(_v, dict)
                    else {"type": type(_v).__name__, "size": len(_v)}
                    if isinstance(_v, (list, tuple, set, frozenset))
                    else {"type": type(_v).__name__}
                )
                for _k, _v in locals().items()
                if _k not in {"self", "cls", "_analytics_logger", "_analytics_class_name", "_analytics_args"}
                and not _k.startswith("_analytics")
            }
            _analytics_logger.debug("%s.%s entered | args=%s", _analytics_class_name, "handle_raw_message", _analytics_args)
        except Exception:
            pass
        key = self._extract_key(payload)

        if key is not None and not self.config.should_process_key(key):
            self._filtered_scope += 1
            self.logger.debug(
                "Liquidation payload ignored due to scoped filters",
                extra={
                    "scope": liquidation_key_to_dict(key),
                    "scope_key": scoped_key_to_string(key),
                },
            )
            return None

        fingerprint = self._make_payload_fingerprint(payload)

        if self.config.deduplication_enabled:
            if self._is_duplicate_payload_fingerprint(fingerprint):
                self._dropped_duplicates += 1
                self.logger.debug(
                    "Duplicate liquidation payload dropped | fingerprint=%s",
                    fingerprint,
                )
                return None
            self._remember_payload_fingerprint(fingerprint)

        if self.config.emit_raw_events:
            await self._publish_raw_payload(payload, fingerprint=fingerprint)

        event = self.normalize_event(payload, raw_payload_hash=fingerprint)
        if event is None:
            self._dropped_invalid += 1
            self.metrics.observe_invalid_event(
                exchange=self._extract_exchange(payload) or None,
                market_type=self._extract_market_type(payload) or None,
                symbol=self._extract_symbol(payload) or None,
                timeframe=self._extract_timeframe(payload) or None,
            )
            return None

        if not self.config.should_process_key(event.key):
            self._filtered_scope += 1
            return None

        is_large = event.is_large_at(self.config.large_liquidation_threshold_usd)

        if not event.is_valid:
            self._dropped_invalid += 1
            self.metrics.observe_event(
                event,
                is_valid=False,
                is_stale=False,
                is_large=False,
            )
            return None

        if is_stale_event(
            event,
            stale_after_seconds=self.config.stale_event_threshold_seconds,
        ):
            self._dropped_stale += 1
            self.metrics.observe_event(
                event,
                is_valid=True,
                is_stale=True,
                is_large=is_large,
            )
            self.logger.debug(
                "Stale liquidation event dropped | exchange=%s market_type=%s "
                "symbol=%s timeframe=%s event_ts=%s",
                event.exchange,
                event.market_type,
                event.symbol,
                event.timeframe,
                event.timestamp.isoformat(),
                extra={
                    "scope": liquidation_key_to_dict(event.key),
                    "exchange_symbol": event.exchange_symbol,
                },
            )
            return None

        symbol_state = self.state.add_event(event)
        self._processed_events += 1
        self._last_event_at = ensure_utc(event.timestamp)

        self.metrics.observe_event(
            event,
            is_valid=True,
            is_stale=False,
            is_large=is_large,
        )
        await self._append_history_event(event, is_large=is_large)

        await self.publish_event(event)
        await self.publish_updated_event(
            event,
            symbol_state_total=getattr(symbol_state, "total_buffered_events", None),
        )

        if is_large and self.config.emit_large_events:
            self._recent_large_events.append(event)
            await self.publish_large_event(event)

        self.logger.debug(
            "Liquidation event processed | exchange=%s market_type=%s symbol=%s "
            "timeframe=%s side=%s notional=%s buffered_events=%s",
            event.exchange,
            event.market_type,
            event.symbol,
            event.timeframe,
            event.side.value,
            str(event.notional_usd),
            getattr(symbol_state, "total_buffered_events", None),
            extra={
                "scope": liquidation_key_to_dict(event.key),
                "exchange_symbol": event.exchange_symbol,
            },
        )
        return event

    def normalize_event(
        self,
        payload: dict[str, Any],
        *,
        raw_payload_hash: str | None = None,
    ) -> LiquidationEvent | None:
        """
        Normalize a flat or exchange-shaped liquidation payload into LiquidationEvent.
        """
        try:
            _analytics_logger = getattr(self, "logger", None) or getattr(self, "_logger", None)
            if _analytics_logger is None:
                _analytics_logger = get_logger(f"{__name__}.{self.__class__.__name__}")
                self.logger = _analytics_logger
            _analytics_class_name = self.__class__.__name__
            _analytics_args = {
                _k: (
                    {"type": "dict", "size": len(_v), "keys": [str(_key) for _key in list(_v.keys())[:20]]}
                    if isinstance(_v, dict)
                    else {"type": type(_v).__name__, "size": len(_v)}
                    if isinstance(_v, (list, tuple, set, frozenset))
                    else {"type": type(_v).__name__}
                )
                for _k, _v in locals().items()
                if _k not in {"self", "cls", "_analytics_logger", "_analytics_class_name", "_analytics_args"}
                and not _k.startswith("_analytics")
            }
            _analytics_logger.debug("%s.%s entered | args=%s", _analytics_class_name, "normalize_event", _analytics_args)
        except Exception:
            pass
        try:
            exchange = self._extract_exchange(payload)
            symbol = self._extract_symbol(payload)
            market_type = self._extract_market_type(payload)
            timeframe = self._extract_timeframe(payload)
            exchange_symbol = self._extract_exchange_symbol(payload, fallback_symbol=symbol)

            side = self._extract_side(payload)
            price = self._extract_price(payload)
            quantity = self._extract_quantity(payload)
            notional_usd = self._extract_notional(payload, price=price, quantity=quantity)
            timestamp = self._extract_timestamp(payload)

            if (
                not exchange
                or not symbol
                or not side.is_known
                or price <= 0
                or quantity <= 0
                or notional_usd <= 0
            ):
                return None

            key = make_liquidation_key(
                exchange=exchange,
                market_type=market_type,
                symbol=symbol,
                timeframe=timeframe,
            )

            return LiquidationEvent(
                exchange=exchange,
                market_type=market_type,
                symbol=symbol,
                timeframe=timeframe,
                exchange_symbol=exchange_symbol,
                side=side,
                price=price,
                quantity=quantity,
                notional_usd=notional_usd,
                timestamp=timestamp,
                event_type=LiquidationEventType.NORMALIZED,
                trade_id=self._extract_trade_id(payload),
                order_id=self._extract_order_id(payload),
                event_id=self._extract_event_id(payload),
                correlation_id=self._extract_correlation_id(payload),
                source=self.service_name,
                raw_payload_hash=raw_payload_hash,
                metadata={
                    "scope": liquidation_key_to_dict(key),
                    "exchange_symbol": exchange_symbol,
                    "raw_type": payload.get("type") or payload.get("e") or payload.get("event"),
                    "source_topic": payload.get("source_topic"),
                    "source_payload_keys": sorted(str(key) for key in payload.keys()),
                },
            )
        except Exception as exc:
            self._last_error = repr(exc)
            self._last_error_at = utc_now()
            self.logger.exception(
                "Failed to normalize liquidation payload | error=%s payload_preview=%s",
                repr(exc),
                self._safe_payload_preview(payload),
            )
            return None

    # ------------------------------------------------------------------
    # Publishing
    # ------------------------------------------------------------------

    async def publish_event(self, event: LiquidationEvent) -> bool:
        try:
            _analytics_logger = getattr(self, "logger", None) or getattr(self, "_logger", None)
            if _analytics_logger is None:
                _analytics_logger = get_logger(f"{__name__}.{self.__class__.__name__}")
                self.logger = _analytics_logger
            _analytics_class_name = self.__class__.__name__
            _analytics_args = {
                _k: (
                    {"type": "dict", "size": len(_v), "keys": [str(_key) for _key in list(_v.keys())[:20]]}
                    if isinstance(_v, dict)
                    else {"type": type(_v).__name__, "size": len(_v)}
                    if isinstance(_v, (list, tuple, set, frozenset))
                    else {"type": type(_v).__name__}
                )
                for _k, _v in locals().items()
                if _k not in {"self", "cls", "_analytics_logger", "_analytics_class_name", "_analytics_args"}
                and not _k.startswith("_analytics")
            }
            _analytics_logger.debug("%s.%s entered | args=%s", _analytics_class_name, "publish_event", _analytics_args)
        except Exception:
            pass
        strategy_payload = ensure_strategy_payload_contract(
            event,
            topic=self.config.publish_topic_normalized,
            source=self.service_name,
            domain="liquidations",
        )
        accepted = await self.event_bus.emit(
            self.config.publish_topic_normalized,
            strategy_payload,
            priority=EventPriority.NORMAL,
            source=self.service_name,
            correlation_id=event.correlation_id,
            headers=self._headers_for_event(
                event,
                event_type=event.event_type,
            ),
        )
        if accepted:
            self._published_normalized += 1
        return accepted

    async def publish_updated_event(
        self,
        event: LiquidationEvent,
        *,
        symbol_state_total: int | None = None,
    ) -> bool:
        try:
            _analytics_logger = getattr(self, "logger", None) or getattr(self, "_logger", None)
            if _analytics_logger is None:
                _analytics_logger = get_logger(f"{__name__}.{self.__class__.__name__}")
                self.logger = _analytics_logger
            _analytics_class_name = self.__class__.__name__
            _analytics_args = {
                _k: (
                    {"type": "dict", "size": len(_v), "keys": [str(_key) for _key in list(_v.keys())[:20]]}
                    if isinstance(_v, dict)
                    else {"type": type(_v).__name__, "size": len(_v)}
                    if isinstance(_v, (list, tuple, set, frozenset))
                    else {"type": type(_v).__name__}
                )
                for _k, _v in locals().items()
                if _k not in {"self", "cls", "_analytics_logger", "_analytics_class_name", "_analytics_args"}
                and not _k.startswith("_analytics")
            }
            _analytics_logger.debug("%s.%s entered | args=%s", _analytics_class_name, "publish_updated_event", _analytics_args)
        except Exception:
            pass
        payload = {
            "exchange": event.exchange,
            "market_type": event.market_type,
            "symbol": event.symbol,
            "timeframe": event.timeframe,
            "exchange_symbol": event.exchange_symbol,
            "scope": liquidation_key_to_dict(event.key),
            "scope_key": scoped_key_to_string(event.key),
            "event": event.to_dict(serialize=True),
            "last_event_at": event.timestamp.isoformat(),
            "last_received_at": event.received_at.isoformat(),
            "symbol_state_total": symbol_state_total,
        }
        strategy_payload = ensure_strategy_payload_contract(
            payload,
            topic=self.publish_topic_updated,
            source=self.service_name,
            domain="liquidations",
        )
        accepted = await self.event_bus.emit(
            self.publish_topic_updated,
            strategy_payload,
            priority=EventPriority.NORMAL,
            source=self.service_name,
            correlation_id=event.correlation_id,
            headers=self._headers_for_event(
                event,
                event_type=LiquidationEventType.NORMALIZED,
                extra={"event_type": "updated"},
            ),
        )
        if accepted:
            self._published_updated += 1
        return accepted

    async def publish_large_event(self, event: LiquidationEvent) -> bool:
        try:
            _analytics_logger = getattr(self, "logger", None) or getattr(self, "_logger", None)
            if _analytics_logger is None:
                _analytics_logger = get_logger(f"{__name__}.{self.__class__.__name__}")
                self.logger = _analytics_logger
            _analytics_class_name = self.__class__.__name__
            _analytics_args = {
                _k: (
                    {"type": "dict", "size": len(_v), "keys": [str(_key) for _key in list(_v.keys())[:20]]}
                    if isinstance(_v, dict)
                    else {"type": type(_v).__name__, "size": len(_v)}
                    if isinstance(_v, (list, tuple, set, frozenset))
                    else {"type": type(_v).__name__}
                )
                for _k, _v in locals().items()
                if _k not in {"self", "cls", "_analytics_logger", "_analytics_class_name", "_analytics_args"}
                and not _k.startswith("_analytics")
            }
            _analytics_logger.debug("%s.%s entered | args=%s", _analytics_class_name, "publish_large_event", _analytics_args)
        except Exception:
            pass
        strategy_payload = ensure_strategy_payload_contract(
            event,
            topic=self.config.publish_topic_large,
            source=self.service_name,
            domain="liquidations",
        )
        accepted = await self.event_bus.emit(
            self.config.publish_topic_large,
            strategy_payload,
            priority=EventPriority.HIGH,
            source=self.service_name,
            correlation_id=event.correlation_id,
            headers=self._headers_for_event(
                event,
                event_type=LiquidationEventType.LARGE,
            ),
        )
        if accepted:
            self._published_large += 1
        return accepted

    async def _publish_raw_payload(
        self,
        payload: dict[str, Any],
        *,
        fingerprint: str,
    ) -> bool:
        try:
            _analytics_logger = getattr(self, "logger", None) or getattr(self, "_logger", None)
            if _analytics_logger is None:
                _analytics_logger = get_logger(f"{__name__}.{self.__class__.__name__}")
                self.logger = _analytics_logger
            _analytics_class_name = self.__class__.__name__
            _analytics_args = {
                _k: (
                    {"type": "dict", "size": len(_v), "keys": [str(_key) for _key in list(_v.keys())[:20]]}
                    if isinstance(_v, dict)
                    else {"type": type(_v).__name__, "size": len(_v)}
                    if isinstance(_v, (list, tuple, set, frozenset))
                    else {"type": type(_v).__name__}
                )
                for _k, _v in locals().items()
                if _k not in {"self", "cls", "_analytics_logger", "_analytics_class_name", "_analytics_args"}
                and not _k.startswith("_analytics")
            }
            _analytics_logger.debug("%s.%s entered | args=%s", _analytics_class_name, "_publish_raw_payload", _analytics_args)
        except Exception:
            pass
        exchange = self._extract_exchange(payload) or "unknown"
        symbol = self._extract_symbol(payload) or None
        market_type = self._extract_market_type(payload)
        timeframe = self._extract_timeframe(payload)
        exchange_symbol = (
            self._extract_exchange_symbol(payload, fallback_symbol=symbol or "")
            if symbol
            else None
        )

        raw_event = {
            "exchange": exchange,
            "market_type": market_type,
            "symbol": symbol,
            "timeframe": timeframe,
            "exchange_symbol": exchange_symbol,
            "received_at": utc_now().isoformat(),
            "fingerprint": fingerprint,
            "payload": payload,
        }

        headers = {
            "exchange": exchange,
            "market_type": market_type,
            "timeframe": timeframe,
            "event_type": LiquidationEventType.RAW.value,
        }
        if symbol:
            headers["symbol"] = symbol
        if exchange_symbol:
            headers["exchange_symbol"] = exchange_symbol

        accepted = await self.event_bus.emit(
            self.config.publish_topic_raw,
            raw_event,
            priority=EventPriority.LOW,
            source=self.service_name,
            headers=headers,
        )
        if accepted:
            self._published_raw += 1
        return accepted

    async def emit_runtime_snapshot(self, topic: str | None = None) -> bool:
        try:
            _analytics_logger = getattr(self, "logger", None) or getattr(self, "_logger", None)
            if _analytics_logger is None:
                _analytics_logger = get_logger(f"{__name__}.{self.__class__.__name__}")
                self.logger = _analytics_logger
            _analytics_class_name = self.__class__.__name__
            _analytics_args = {
                _k: (
                    {"type": "dict", "size": len(_v), "keys": [str(_key) for _key in list(_v.keys())[:20]]}
                    if isinstance(_v, dict)
                    else {"type": type(_v).__name__, "size": len(_v)}
                    if isinstance(_v, (list, tuple, set, frozenset))
                    else {"type": type(_v).__name__}
                )
                for _k, _v in locals().items()
                if _k not in {"self", "cls", "_analytics_logger", "_analytics_class_name", "_analytics_args"}
                and not _k.startswith("_analytics")
            }
            _analytics_logger.debug("%s.%s entered | args=%s", _analytics_class_name, "emit_runtime_snapshot", _analytics_args)
        except Exception:
            pass
        snapshot = {
            "service": self.service_name,
            "input_topics": list(self.config.input_topics),
            "health": self.estimate_ingestion_health(),
            "stats": self.get_stats(),
            "metrics": self.metrics.to_dict(serialize=True),
            "state": [item.to_dict(serialize=True) for item in self.state.snapshots()],
            "scope": "exchange:market_type:symbol:timeframe",
            "emitted_at": utc_now().isoformat(),
        }
        accepted = await self.event_bus.emit(
            topic or self.config.publish_topic_snapshot,
            snapshot,
            priority=EventPriority.LOW,
            source=self.service_name,
            headers={"event_type": LiquidationEventType.SNAPSHOT.value},
        )
        if accepted:
            self._published_snapshots += 1
        return accepted

    async def emit_health(self) -> bool:
        try:
            _analytics_logger = getattr(self, "logger", None) or getattr(self, "_logger", None)
            if _analytics_logger is None:
                _analytics_logger = get_logger(f"{__name__}.{self.__class__.__name__}")
                self.logger = _analytics_logger
            _analytics_class_name = self.__class__.__name__
            _analytics_args = {
                _k: (
                    {"type": "dict", "size": len(_v), "keys": [str(_key) for _key in list(_v.keys())[:20]]}
                    if isinstance(_v, dict)
                    else {"type": type(_v).__name__, "size": len(_v)}
                    if isinstance(_v, (list, tuple, set, frozenset))
                    else {"type": type(_v).__name__}
                )
                for _k, _v in locals().items()
                if _k not in {"self", "cls", "_analytics_logger", "_analytics_class_name", "_analytics_args"}
                and not _k.startswith("_analytics")
            }
            _analytics_logger.debug("%s.%s entered | args=%s", _analytics_class_name, "emit_health", _analytics_args)
        except Exception:
            pass
        health = self.estimate_ingestion_health()
        accepted = await self.event_bus.emit(
            self.config.publish_topic_health,
            health,
            priority=EventPriority.LOW,
            source=self.service_name,
            headers={"event_type": LiquidationEventType.HEALTH.value},
        )
        if accepted:
            self._published_health += 1
        return accepted

    # ------------------------------------------------------------------
    # Optional storage hook
    # ------------------------------------------------------------------

    async def _append_history_event(
        self,
        event: LiquidationEvent,
        *,
        is_large: bool,
    ) -> None:
        try:
            _analytics_logger = getattr(self, "logger", None) or getattr(self, "_logger", None)
            if _analytics_logger is None:
                _analytics_logger = get_logger(f"{__name__}.{self.__class__.__name__}")
                self.logger = _analytics_logger
            _analytics_class_name = self.__class__.__name__
            _analytics_args = {
                _k: (
                    {"type": "dict", "size": len(_v), "keys": [str(_key) for _key in list(_v.keys())[:20]]}
                    if isinstance(_v, dict)
                    else {"type": type(_v).__name__, "size": len(_v)}
                    if isinstance(_v, (list, tuple, set, frozenset))
                    else {"type": type(_v).__name__}
                )
                for _k, _v in locals().items()
                if _k not in {"self", "cls", "_analytics_logger", "_analytics_class_name", "_analytics_args"}
                and not _k.startswith("_analytics")
            }
            _analytics_logger.debug("%s.%s entered | args=%s", _analytics_class_name, "_append_history_event", _analytics_args)
        except Exception:
            pass
        if self.history_store is None:
            return

        try:
            await self.history_store.append_event(event)
            if is_large:
                await self.history_store.append_large_event(event)
        except Exception as exc:
            self._storage_errors += 1
            self._last_error = repr(exc)
            self._last_error_at = utc_now()
            self.logger.exception(
                "Failed to append liquidation event to history store | "
                "exchange=%s market_type=%s symbol=%s timeframe=%s error=%s",
                event.exchange,
                event.market_type,
                event.symbol,
                event.timeframe,
                repr(exc),
                extra={
                    "scope": liquidation_key_to_dict(event.key),
                    "exchange_symbol": event.exchange_symbol,
                },
            )

    async def _flush_history_store(self) -> None:
        try:
            _analytics_logger = getattr(self, "logger", None) or getattr(self, "_logger", None)
            if _analytics_logger is None:
                _analytics_logger = get_logger(f"{__name__}.{self.__class__.__name__}")
                self.logger = _analytics_logger
            _analytics_class_name = self.__class__.__name__
            _analytics_args = {
                _k: (
                    {"type": "dict", "size": len(_v), "keys": [str(_key) for _key in list(_v.keys())[:20]]}
                    if isinstance(_v, dict)
                    else {"type": type(_v).__name__, "size": len(_v)}
                    if isinstance(_v, (list, tuple, set, frozenset))
                    else {"type": type(_v).__name__}
                )
                for _k, _v in locals().items()
                if _k not in {"self", "cls", "_analytics_logger", "_analytics_class_name", "_analytics_args"}
                and not _k.startswith("_analytics")
            }
            _analytics_logger.debug("%s.%s entered | args=%s", _analytics_class_name, "_flush_history_store", _analytics_args)
        except Exception:
            pass
        if self.history_store is None:
            return

        try:
            await self.history_store.flush()
        except Exception as exc:
            self._storage_errors += 1
            self.logger.exception(
                "Failed to flush liquidation history store | error=%s",
                repr(exc),
            )

    # ------------------------------------------------------------------
    # Extraction helpers
    # ------------------------------------------------------------------

    def _nested_order(self, payload: dict[str, Any]) -> dict[str, Any]:
        try:
            _analytics_logger = getattr(self, "logger", None) or getattr(self, "_logger", None)
            if _analytics_logger is None:
                _analytics_logger = get_logger(f"{__name__}.{self.__class__.__name__}")
                self.logger = _analytics_logger
            _analytics_class_name = self.__class__.__name__
            _analytics_args = {
                _k: (
                    {"type": "dict", "size": len(_v), "keys": [str(_key) for _key in list(_v.keys())[:20]]}
                    if isinstance(_v, dict)
                    else {"type": type(_v).__name__, "size": len(_v)}
                    if isinstance(_v, (list, tuple, set, frozenset))
                    else {"type": type(_v).__name__}
                )
                for _k, _v in locals().items()
                if _k not in {"self", "cls", "_analytics_logger", "_analytics_class_name", "_analytics_args"}
                and not _k.startswith("_analytics")
            }
            _analytics_logger.debug("%s.%s entered | args=%s", _analytics_class_name, "_nested_order", _analytics_args)
        except Exception:
            pass
        for key in ("o", "order", "data", "payload"):
            value = payload.get(key)
            if isinstance(value, dict):
                return value
        return {}

    def _pick(self, payload: dict[str, Any], *keys: str) -> Any:
        try:
            _analytics_logger = getattr(self, "logger", None) or getattr(self, "_logger", None)
            if _analytics_logger is None:
                _analytics_logger = get_logger(f"{__name__}.{self.__class__.__name__}")
                self.logger = _analytics_logger
            _analytics_class_name = self.__class__.__name__
            _analytics_args = {
                _k: (
                    {"type": "dict", "size": len(_v), "keys": [str(_key) for _key in list(_v.keys())[:20]]}
                    if isinstance(_v, dict)
                    else {"type": type(_v).__name__, "size": len(_v)}
                    if isinstance(_v, (list, tuple, set, frozenset))
                    else {"type": type(_v).__name__}
                )
                for _k, _v in locals().items()
                if _k not in {"self", "cls", "_analytics_logger", "_analytics_class_name", "_analytics_args"}
                and not _k.startswith("_analytics")
            }
            _analytics_logger.debug("%s.%s entered | args=%s", _analytics_class_name, "_pick", _analytics_args)
        except Exception:
            pass
        nested = self._nested_order(payload)

        for key in keys:
            if key in payload and payload[key] not in (None, ""):
                return payload[key]

        for key in keys:
            if key in nested and nested[key] not in (None, ""):
                return nested[key]

        return None

    def _extract_exchange(self, payload: dict[str, Any]) -> str:
        try:
            _analytics_logger = getattr(self, "logger", None) or getattr(self, "_logger", None)
            if _analytics_logger is None:
                _analytics_logger = get_logger(f"{__name__}.{self.__class__.__name__}")
                self.logger = _analytics_logger
            _analytics_class_name = self.__class__.__name__
            _analytics_args = {
                _k: (
                    {"type": "dict", "size": len(_v), "keys": [str(_key) for _key in list(_v.keys())[:20]]}
                    if isinstance(_v, dict)
                    else {"type": type(_v).__name__, "size": len(_v)}
                    if isinstance(_v, (list, tuple, set, frozenset))
                    else {"type": type(_v).__name__}
                )
                for _k, _v in locals().items()
                if _k not in {"self", "cls", "_analytics_logger", "_analytics_class_name", "_analytics_args"}
                and not _k.startswith("_analytics")
            }
            _analytics_logger.debug("%s.%s entered | args=%s", _analytics_class_name, "_extract_exchange", _analytics_args)
        except Exception:
            pass
        value = self._pick(payload, "exchange", "ex", "exchangeName", "source_exchange")
        if value is None and len(self.config.exchanges) == 1:
            value = self.config.exchanges[0]
        return normalize_exchange(value or "unknown")

    def _extract_symbol(self, payload: dict[str, Any]) -> str:
        try:
            _analytics_logger = getattr(self, "logger", None) or getattr(self, "_logger", None)
            if _analytics_logger is None:
                _analytics_logger = get_logger(f"{__name__}.{self.__class__.__name__}")
                self.logger = _analytics_logger
            _analytics_class_name = self.__class__.__name__
            _analytics_args = {
                _k: (
                    {"type": "dict", "size": len(_v), "keys": [str(_key) for _key in list(_v.keys())[:20]]}
                    if isinstance(_v, dict)
                    else {"type": type(_v).__name__, "size": len(_v)}
                    if isinstance(_v, (list, tuple, set, frozenset))
                    else {"type": type(_v).__name__}
                )
                for _k, _v in locals().items()
                if _k not in {"self", "cls", "_analytics_logger", "_analytics_class_name", "_analytics_args"}
                and not _k.startswith("_analytics")
            }
            _analytics_logger.debug("%s.%s entered | args=%s", _analytics_class_name, "_extract_symbol", _analytics_args)
        except Exception:
            pass
        value = self._pick(
            payload,
            "symbol",
            "s",
            "market",
            "instrument",
            "instId",
            "inst_id",
            "pair",
        )
        if value is None:
            return ""
        return normalize_symbol(value)

    def _extract_market_type(self, payload: dict[str, Any]) -> str:
        try:
            _analytics_logger = getattr(self, "logger", None) or getattr(self, "_logger", None)
            if _analytics_logger is None:
                _analytics_logger = get_logger(f"{__name__}.{self.__class__.__name__}")
                self.logger = _analytics_logger
            _analytics_class_name = self.__class__.__name__
            _analytics_args = {
                _k: (
                    {"type": "dict", "size": len(_v), "keys": [str(_key) for _key in list(_v.keys())[:20]]}
                    if isinstance(_v, dict)
                    else {"type": type(_v).__name__, "size": len(_v)}
                    if isinstance(_v, (list, tuple, set, frozenset))
                    else {"type": type(_v).__name__}
                )
                for _k, _v in locals().items()
                if _k not in {"self", "cls", "_analytics_logger", "_analytics_class_name", "_analytics_args"}
                and not _k.startswith("_analytics")
            }
            _analytics_logger.debug("%s.%s entered | args=%s", _analytics_class_name, "_extract_market_type", _analytics_args)
        except Exception:
            pass
        value = self._pick(
            payload,
            "market_type",
            "marketType",
            "category",
            "market_category",
            "contract_type",
            "contractType",
            "instrument_type",
            "instType",
        )
        return normalize_market_type(value or self.config.default_market_type or DEFAULT_MARKET_TYPE)

    def _extract_timeframe(self, payload: dict[str, Any]) -> str:
        try:
            _analytics_logger = getattr(self, "logger", None) or getattr(self, "_logger", None)
            if _analytics_logger is None:
                _analytics_logger = get_logger(f"{__name__}.{self.__class__.__name__}")
                self.logger = _analytics_logger
            _analytics_class_name = self.__class__.__name__
            _analytics_args = {
                _k: (
                    {"type": "dict", "size": len(_v), "keys": [str(_key) for _key in list(_v.keys())[:20]]}
                    if isinstance(_v, dict)
                    else {"type": type(_v).__name__, "size": len(_v)}
                    if isinstance(_v, (list, tuple, set, frozenset))
                    else {"type": type(_v).__name__}
                )
                for _k, _v in locals().items()
                if _k not in {"self", "cls", "_analytics_logger", "_analytics_class_name", "_analytics_args"}
                and not _k.startswith("_analytics")
            }
            _analytics_logger.debug("%s.%s entered | args=%s", _analytics_class_name, "_extract_timeframe", _analytics_args)
        except Exception:
            pass
        value = self._pick(payload, "timeframe", "tf", "window", "interval")
        return normalize_timeframe(value or self.config.default_timeframe or DEFAULT_TIMEFRAME)

    def _extract_exchange_symbol(
        self,
        payload: dict[str, Any],
        *,
        fallback_symbol: str,
    ) -> str:
        try:
            _analytics_logger = getattr(self, "logger", None) or getattr(self, "_logger", None)
            if _analytics_logger is None:
                _analytics_logger = get_logger(f"{__name__}.{self.__class__.__name__}")
                self.logger = _analytics_logger
            _analytics_class_name = self.__class__.__name__
            _analytics_args = {
                _k: (
                    {"type": "dict", "size": len(_v), "keys": [str(_key) for _key in list(_v.keys())[:20]]}
                    if isinstance(_v, dict)
                    else {"type": type(_v).__name__, "size": len(_v)}
                    if isinstance(_v, (list, tuple, set, frozenset))
                    else {"type": type(_v).__name__}
                )
                for _k, _v in locals().items()
                if _k not in {"self", "cls", "_analytics_logger", "_analytics_class_name", "_analytics_args"}
                and not _k.startswith("_analytics")
            }
            _analytics_logger.debug("%s.%s entered | args=%s", _analytics_class_name, "_extract_exchange_symbol", _analytics_args)
        except Exception:
            pass
        value = self._pick(
            payload,
            "exchange_symbol",
            "raw_symbol",
            "native_symbol",
            "instrument",
            "instId",
            "inst_id",
            "s",
            "symbol",
        )
        return normalize_exchange_symbol(value, fallback_symbol=fallback_symbol)

    def _extract_key(self, payload: dict[str, Any]) -> LiquidationKey | None:
        try:
            _analytics_logger = getattr(self, "logger", None) or getattr(self, "_logger", None)
            if _analytics_logger is None:
                _analytics_logger = get_logger(f"{__name__}.{self.__class__.__name__}")
                self.logger = _analytics_logger
            _analytics_class_name = self.__class__.__name__
            _analytics_args = {
                _k: (
                    {"type": "dict", "size": len(_v), "keys": [str(_key) for _key in list(_v.keys())[:20]]}
                    if isinstance(_v, dict)
                    else {"type": type(_v).__name__, "size": len(_v)}
                    if isinstance(_v, (list, tuple, set, frozenset))
                    else {"type": type(_v).__name__}
                )
                for _k, _v in locals().items()
                if _k not in {"self", "cls", "_analytics_logger", "_analytics_class_name", "_analytics_args"}
                and not _k.startswith("_analytics")
            }
            _analytics_logger.debug("%s.%s entered | args=%s", _analytics_class_name, "_extract_key", _analytics_args)
        except Exception:
            pass
        symbol = self._extract_symbol(payload)
        if not symbol:
            return None

        try:
            return make_liquidation_key(
                exchange=self._extract_exchange(payload),
                market_type=self._extract_market_type(payload),
                symbol=symbol,
                timeframe=self._extract_timeframe(payload),
            )
        except ValueError:
            return None

    def _extract_side(self, payload: dict[str, Any]) -> LiquidationSide:
        try:
            _analytics_logger = getattr(self, "logger", None) or getattr(self, "_logger", None)
            if _analytics_logger is None:
                _analytics_logger = get_logger(f"{__name__}.{self.__class__.__name__}")
                self.logger = _analytics_logger
            _analytics_class_name = self.__class__.__name__
            _analytics_args = {
                _k: (
                    {"type": "dict", "size": len(_v), "keys": [str(_key) for _key in list(_v.keys())[:20]]}
                    if isinstance(_v, dict)
                    else {"type": type(_v).__name__, "size": len(_v)}
                    if isinstance(_v, (list, tuple, set, frozenset))
                    else {"type": type(_v).__name__}
                )
                for _k, _v in locals().items()
                if _k not in {"self", "cls", "_analytics_logger", "_analytics_class_name", "_analytics_args"}
                and not _k.startswith("_analytics")
            }
            _analytics_logger.debug("%s.%s entered | args=%s", _analytics_class_name, "_extract_side", _analytics_args)
        except Exception:
            pass
        value = self._pick(
            payload,
            "side",
            "S",
            "positionSide",
            "liquidation_side",
            "liquidationSide",
            "direction",
            "posSide",
        )
        return LiquidationSide.from_raw(value)

    def _extract_price(self, payload: dict[str, Any]) -> Decimal:
        try:
            _analytics_logger = getattr(self, "logger", None) or getattr(self, "_logger", None)
            if _analytics_logger is None:
                _analytics_logger = get_logger(f"{__name__}.{self.__class__.__name__}")
                self.logger = _analytics_logger
            _analytics_class_name = self.__class__.__name__
            _analytics_args = {
                _k: (
                    {"type": "dict", "size": len(_v), "keys": [str(_key) for _key in list(_v.keys())[:20]]}
                    if isinstance(_v, dict)
                    else {"type": type(_v).__name__, "size": len(_v)}
                    if isinstance(_v, (list, tuple, set, frozenset))
                    else {"type": type(_v).__name__}
                )
                for _k, _v in locals().items()
                if _k not in {"self", "cls", "_analytics_logger", "_analytics_class_name", "_analytics_args"}
                and not _k.startswith("_analytics")
            }
            _analytics_logger.debug("%s.%s entered | args=%s", _analytics_class_name, "_extract_price", _analytics_args)
        except Exception:
            pass
        value = self._pick(
            payload,
            "price",
            "p",
            "ap",
            "fillPrice",
            "avgPrice",
            "avg_price",
            "px",
            "triggerPx",
        )
        return safe_decimal(value)

    def _extract_quantity(self, payload: dict[str, Any]) -> Decimal:
        try:
            _analytics_logger = getattr(self, "logger", None) or getattr(self, "_logger", None)
            if _analytics_logger is None:
                _analytics_logger = get_logger(f"{__name__}.{self.__class__.__name__}")
                self.logger = _analytics_logger
            _analytics_class_name = self.__class__.__name__
            _analytics_args = {
                _k: (
                    {"type": "dict", "size": len(_v), "keys": [str(_key) for _key in list(_v.keys())[:20]]}
                    if isinstance(_v, dict)
                    else {"type": type(_v).__name__, "size": len(_v)}
                    if isinstance(_v, (list, tuple, set, frozenset))
                    else {"type": type(_v).__name__}
                )
                for _k, _v in locals().items()
                if _k not in {"self", "cls", "_analytics_logger", "_analytics_class_name", "_analytics_args"}
                and not _k.startswith("_analytics")
            }
            _analytics_logger.debug("%s.%s entered | args=%s", _analytics_class_name, "_extract_quantity", _analytics_args)
        except Exception:
            pass
        value = self._pick(
            payload,
            "quantity",
            "qty",
            "q",
            "size",
            "sz",
            "vol",
            "amount",
            "filledQty",
        )
        return safe_decimal(value)

    def _extract_notional(
        self,
        payload: dict[str, Any],
        *,
        price: Decimal,
        quantity: Decimal,
    ) -> Decimal:
        try:
            _analytics_logger = getattr(self, "logger", None) or getattr(self, "_logger", None)
            if _analytics_logger is None:
                _analytics_logger = get_logger(f"{__name__}.{self.__class__.__name__}")
                self.logger = _analytics_logger
            _analytics_class_name = self.__class__.__name__
            _analytics_args = {
                _k: (
                    {"type": "dict", "size": len(_v), "keys": [str(_key) for _key in list(_v.keys())[:20]]}
                    if isinstance(_v, dict)
                    else {"type": type(_v).__name__, "size": len(_v)}
                    if isinstance(_v, (list, tuple, set, frozenset))
                    else {"type": type(_v).__name__}
                )
                for _k, _v in locals().items()
                if _k not in {"self", "cls", "_analytics_logger", "_analytics_class_name", "_analytics_args"}
                and not _k.startswith("_analytics")
            }
            _analytics_logger.debug("%s.%s entered | args=%s", _analytics_class_name, "_extract_notional", _analytics_args)
        except Exception:
            pass
        value = self._pick(
            payload,
            "notional_usd",
            "notional",
            "value",
            "usd_value",
            "turnover",
            "quoteQty",
        )
        notional = safe_decimal(value)
        if notional > Decimal("0"):
            return notional
        return price * quantity

    def _extract_timestamp(self, payload: dict[str, Any]) -> datetime:
        try:
            _analytics_logger = getattr(self, "logger", None) or getattr(self, "_logger", None)
            if _analytics_logger is None:
                _analytics_logger = get_logger(f"{__name__}.{self.__class__.__name__}")
                self.logger = _analytics_logger
            _analytics_class_name = self.__class__.__name__
            _analytics_args = {
                _k: (
                    {"type": "dict", "size": len(_v), "keys": [str(_key) for _key in list(_v.keys())[:20]]}
                    if isinstance(_v, dict)
                    else {"type": type(_v).__name__, "size": len(_v)}
                    if isinstance(_v, (list, tuple, set, frozenset))
                    else {"type": type(_v).__name__}
                )
                for _k, _v in locals().items()
                if _k not in {"self", "cls", "_analytics_logger", "_analytics_class_name", "_analytics_args"}
                and not _k.startswith("_analytics")
            }
            _analytics_logger.debug("%s.%s entered | args=%s", _analytics_class_name, "_extract_timestamp", _analytics_args)
        except Exception:
            pass
        value = self._pick(
            payload,
            "timestamp",
            "timestamp_ms",
            "ts",
            "T",
            "E",
            "time",
            "createdAt",
            "updatedAt",
            "updated_time",
            "updatedTime",
            "execTime",
        )
        if value is None:
            return utc_now()
        return self._parse_datetime(value)

    def _extract_trade_id(self, payload: dict[str, Any]) -> str | None:
        try:
            _analytics_logger = getattr(self, "logger", None) or getattr(self, "_logger", None)
            if _analytics_logger is None:
                _analytics_logger = get_logger(f"{__name__}.{self.__class__.__name__}")
                self.logger = _analytics_logger
            _analytics_class_name = self.__class__.__name__
            _analytics_args = {
                _k: (
                    {"type": "dict", "size": len(_v), "keys": [str(_key) for _key in list(_v.keys())[:20]]}
                    if isinstance(_v, dict)
                    else {"type": type(_v).__name__, "size": len(_v)}
                    if isinstance(_v, (list, tuple, set, frozenset))
                    else {"type": type(_v).__name__}
                )
                for _k, _v in locals().items()
                if _k not in {"self", "cls", "_analytics_logger", "_analytics_class_name", "_analytics_args"}
                and not _k.startswith("_analytics")
            }
            _analytics_logger.debug("%s.%s entered | args=%s", _analytics_class_name, "_extract_trade_id", _analytics_args)
        except Exception:
            pass
        value = self._pick(payload, "trade_id", "tradeId", "t", "execId", "dealId")
        return str(value) if value not in (None, "") else None

    def _extract_order_id(self, payload: dict[str, Any]) -> str | None:
        try:
            _analytics_logger = getattr(self, "logger", None) or getattr(self, "_logger", None)
            if _analytics_logger is None:
                _analytics_logger = get_logger(f"{__name__}.{self.__class__.__name__}")
                self.logger = _analytics_logger
            _analytics_class_name = self.__class__.__name__
            _analytics_args = {
                _k: (
                    {"type": "dict", "size": len(_v), "keys": [str(_key) for _key in list(_v.keys())[:20]]}
                    if isinstance(_v, dict)
                    else {"type": type(_v).__name__, "size": len(_v)}
                    if isinstance(_v, (list, tuple, set, frozenset))
                    else {"type": type(_v).__name__}
                )
                for _k, _v in locals().items()
                if _k not in {"self", "cls", "_analytics_logger", "_analytics_class_name", "_analytics_args"}
                and not _k.startswith("_analytics")
            }
            _analytics_logger.debug("%s.%s entered | args=%s", _analytics_class_name, "_extract_order_id", _analytics_args)
        except Exception:
            pass
        value = self._pick(payload, "order_id", "orderId", "i", "ordId")
        return str(value) if value not in (None, "") else None

    def _extract_event_id(self, payload: dict[str, Any]) -> str | None:
        try:
            _analytics_logger = getattr(self, "logger", None) or getattr(self, "_logger", None)
            if _analytics_logger is None:
                _analytics_logger = get_logger(f"{__name__}.{self.__class__.__name__}")
                self.logger = _analytics_logger
            _analytics_class_name = self.__class__.__name__
            _analytics_args = {
                _k: (
                    {"type": "dict", "size": len(_v), "keys": [str(_key) for _key in list(_v.keys())[:20]]}
                    if isinstance(_v, dict)
                    else {"type": type(_v).__name__, "size": len(_v)}
                    if isinstance(_v, (list, tuple, set, frozenset))
                    else {"type": type(_v).__name__}
                )
                for _k, _v in locals().items()
                if _k not in {"self", "cls", "_analytics_logger", "_analytics_class_name", "_analytics_args"}
                and not _k.startswith("_analytics")
            }
            _analytics_logger.debug("%s.%s entered | args=%s", _analytics_class_name, "_extract_event_id", _analytics_args)
        except Exception:
            pass
        value = self._pick(payload, "event_id", "eventId", "id")
        return str(value) if value not in (None, "") else None

    def _extract_correlation_id(self, payload: dict[str, Any]) -> str | None:
        try:
            _analytics_logger = getattr(self, "logger", None) or getattr(self, "_logger", None)
            if _analytics_logger is None:
                _analytics_logger = get_logger(f"{__name__}.{self.__class__.__name__}")
                self.logger = _analytics_logger
            _analytics_class_name = self.__class__.__name__
            _analytics_args = {
                _k: (
                    {"type": "dict", "size": len(_v), "keys": [str(_key) for _key in list(_v.keys())[:20]]}
                    if isinstance(_v, dict)
                    else {"type": type(_v).__name__, "size": len(_v)}
                    if isinstance(_v, (list, tuple, set, frozenset))
                    else {"type": type(_v).__name__}
                )
                for _k, _v in locals().items()
                if _k not in {"self", "cls", "_analytics_logger", "_analytics_class_name", "_analytics_args"}
                and not _k.startswith("_analytics")
            }
            _analytics_logger.debug("%s.%s entered | args=%s", _analytics_class_name, "_extract_correlation_id", _analytics_args)
        except Exception:
            pass
        value = self._pick(payload, "correlation_id", "correlationId", "trace_id", "traceId")
        return str(value) if value not in (None, "") else None

    def _parse_datetime(self, value: Any) -> datetime:
        try:
            _analytics_logger = getattr(self, "logger", None) or getattr(self, "_logger", None)
            if _analytics_logger is None:
                _analytics_logger = get_logger(f"{__name__}.{self.__class__.__name__}")
                self.logger = _analytics_logger
            _analytics_class_name = self.__class__.__name__
            _analytics_args = {
                _k: (
                    {"type": "dict", "size": len(_v), "keys": [str(_key) for _key in list(_v.keys())[:20]]}
                    if isinstance(_v, dict)
                    else {"type": type(_v).__name__, "size": len(_v)}
                    if isinstance(_v, (list, tuple, set, frozenset))
                    else {"type": type(_v).__name__}
                )
                for _k, _v in locals().items()
                if _k not in {"self", "cls", "_analytics_logger", "_analytics_class_name", "_analytics_args"}
                and not _k.startswith("_analytics")
            }
            _analytics_logger.debug("%s.%s entered | args=%s", _analytics_class_name, "_parse_datetime", _analytics_args)
        except Exception:
            pass
        if isinstance(value, datetime):
            return ensure_utc(value)

        if isinstance(value, (int, float)):
            numeric = float(value)

            # Most exchange timestamps are milliseconds; seconds are also accepted.
            if numeric > 1_000_000_000_000:
                numeric /= 1000.0

            return datetime.fromtimestamp(numeric, tz=utc_now().tzinfo)

        if isinstance(value, str):
            stripped = value.strip()
            if not stripped:
                return utc_now()

            if stripped.isdigit():
                return self._parse_datetime(int(stripped))

            return ensure_utc(datetime.fromisoformat(stripped.replace("Z", "+00:00")))

        return utc_now()

    # ------------------------------------------------------------------
    # Read API
    # ------------------------------------------------------------------

    def get_recent_events(
        self,
        *,
        exchange: str | None = None,
        symbol: str | None = None,
        market_type: str | None = None,
        timeframe: str | None = None,
        side: LiquidationSide | None = None,
        limit: int = 100,
    ) -> list[LiquidationEvent]:
        try:
            _analytics_logger = getattr(self, "logger", None) or getattr(self, "_logger", None)
            if _analytics_logger is None:
                _analytics_logger = get_logger(f"{__name__}.{self.__class__.__name__}")
                self.logger = _analytics_logger
            _analytics_class_name = self.__class__.__name__
            _analytics_args = {
                _k: (
                    {"type": "dict", "size": len(_v), "keys": [str(_key) for _key in list(_v.keys())[:20]]}
                    if isinstance(_v, dict)
                    else {"type": type(_v).__name__, "size": len(_v)}
                    if isinstance(_v, (list, tuple, set, frozenset))
                    else {"type": type(_v).__name__}
                )
                for _k, _v in locals().items()
                if _k not in {"self", "cls", "_analytics_logger", "_analytics_class_name", "_analytics_args"}
                and not _k.startswith("_analytics")
            }
            _analytics_logger.debug("%s.%s entered | args=%s", _analytics_class_name, "get_recent_events", _analytics_args)
        except Exception:
            pass
        return self.state.get_recent_events(
            exchange=exchange,
            market_type=market_type,
            symbol=symbol,
            timeframe=timeframe,
            side=side,
            limit=max(0, limit),
        )

    def get_recent_events_for_key(
        self,
        key: LiquidationKey,
        *,
        side: LiquidationSide | None = None,
        limit: int = 100,
    ) -> list[LiquidationEvent]:
        try:
            _analytics_logger = getattr(self, "logger", None) or getattr(self, "_logger", None)
            if _analytics_logger is None:
                _analytics_logger = get_logger(f"{__name__}.{self.__class__.__name__}")
                self.logger = _analytics_logger
            _analytics_class_name = self.__class__.__name__
            _analytics_args = {
                _k: (
                    {"type": "dict", "size": len(_v), "keys": [str(_key) for _key in list(_v.keys())[:20]]}
                    if isinstance(_v, dict)
                    else {"type": type(_v).__name__, "size": len(_v)}
                    if isinstance(_v, (list, tuple, set, frozenset))
                    else {"type": type(_v).__name__}
                )
                for _k, _v in locals().items()
                if _k not in {"self", "cls", "_analytics_logger", "_analytics_class_name", "_analytics_args"}
                and not _k.startswith("_analytics")
            }
            _analytics_logger.debug("%s.%s entered | args=%s", _analytics_class_name, "get_recent_events_for_key", _analytics_args)
        except Exception:
            pass
        return self.state.get_recent_events_for_key(
            key,
            side=side,
            limit=max(0, limit),
        )

    def get_recent_large_events(
        self,
        *,
        exchange: str | None = None,
        symbol: str | None = None,
        market_type: str | None = None,
        timeframe: str | None = None,
        limit: int = 100,
    ) -> list[LiquidationEvent]:
        try:
            _analytics_logger = getattr(self, "logger", None) or getattr(self, "_logger", None)
            if _analytics_logger is None:
                _analytics_logger = get_logger(f"{__name__}.{self.__class__.__name__}")
                self.logger = _analytics_logger
            _analytics_class_name = self.__class__.__name__
            _analytics_args = {
                _k: (
                    {"type": "dict", "size": len(_v), "keys": [str(_key) for _key in list(_v.keys())[:20]]}
                    if isinstance(_v, dict)
                    else {"type": type(_v).__name__, "size": len(_v)}
                    if isinstance(_v, (list, tuple, set, frozenset))
                    else {"type": type(_v).__name__}
                )
                for _k, _v in locals().items()
                if _k not in {"self", "cls", "_analytics_logger", "_analytics_class_name", "_analytics_args"}
                and not _k.startswith("_analytics")
            }
            _analytics_logger.debug("%s.%s entered | args=%s", _analytics_class_name, "get_recent_large_events", _analytics_args)
        except Exception:
            pass
        if limit <= 0:
            return []

        target_exchange = normalize_exchange(exchange) if exchange is not None else None
        target_symbol = normalize_symbol(symbol) if symbol is not None else None
        target_market_type = (
            normalize_market_type(market_type)
            if market_type is not None
            else None
        )
        target_timeframe = (
            normalize_timeframe(timeframe)
            if timeframe is not None
            else None
        )

        result: list[LiquidationEvent] = []

        for event in reversed(self._recent_large_events):
            if target_exchange and event.exchange != target_exchange:
                continue
            if target_market_type and event.market_type != target_market_type:
                continue
            if target_symbol and event.symbol != target_symbol:
                continue
            if target_timeframe and event.timeframe != target_timeframe:
                continue

            result.append(event)

            if len(result) >= limit:
                break

        return result

    def get_symbol_snapshot(
        self,
        *,
        exchange: str,
        symbol: str,
        market_type: str | None = None,
        timeframe: str | None = None,
    ):
        try:
            _analytics_logger = getattr(self, "logger", None) or getattr(self, "_logger", None)
            if _analytics_logger is None:
                _analytics_logger = get_logger(f"{__name__}.{self.__class__.__name__}")
                self.logger = _analytics_logger
            _analytics_class_name = self.__class__.__name__
            _analytics_args = {
                _k: (
                    {"type": "dict", "size": len(_v), "keys": [str(_key) for _key in list(_v.keys())[:20]]}
                    if isinstance(_v, dict)
                    else {"type": type(_v).__name__, "size": len(_v)}
                    if isinstance(_v, (list, tuple, set, frozenset))
                    else {"type": type(_v).__name__}
                )
                for _k, _v in locals().items()
                if _k not in {"self", "cls", "_analytics_logger", "_analytics_class_name", "_analytics_args"}
                and not _k.startswith("_analytics")
            }
            _analytics_logger.debug("%s.%s entered | args=%s", _analytics_class_name, "get_symbol_snapshot", _analytics_args)
        except Exception:
            pass
        return self.state.snapshot_by_symbol(
            exchange,
            symbol,
            market_type=market_type,
            timeframe=timeframe,
        )

    def get_key_snapshot(self, key: LiquidationKey):
        try:
            _analytics_logger = getattr(self, "logger", None) or getattr(self, "_logger", None)
            if _analytics_logger is None:
                _analytics_logger = get_logger(f"{__name__}.{self.__class__.__name__}")
                self.logger = _analytics_logger
            _analytics_class_name = self.__class__.__name__
            _analytics_args = {
                _k: (
                    {"type": "dict", "size": len(_v), "keys": [str(_key) for _key in list(_v.keys())[:20]]}
                    if isinstance(_v, dict)
                    else {"type": type(_v).__name__, "size": len(_v)}
                    if isinstance(_v, (list, tuple, set, frozenset))
                    else {"type": type(_v).__name__}
                )
                for _k, _v in locals().items()
                if _k not in {"self", "cls", "_analytics_logger", "_analytics_class_name", "_analytics_args"}
                and not _k.startswith("_analytics")
            }
            _analytics_logger.debug("%s.%s entered | args=%s", _analytics_class_name, "get_key_snapshot", _analytics_args)
        except Exception:
            pass
        return self.state.snapshot_by_key(key)

    def get_stats(self) -> dict[str, Any]:
        try:
            _analytics_logger = getattr(self, "logger", None) or getattr(self, "_logger", None)
            if _analytics_logger is None:
                _analytics_logger = get_logger(f"{__name__}.{self.__class__.__name__}")
                self.logger = _analytics_logger
            _analytics_class_name = self.__class__.__name__
            _analytics_args = {
                _k: (
                    {"type": "dict", "size": len(_v), "keys": [str(_key) for _key in list(_v.keys())[:20]]}
                    if isinstance(_v, dict)
                    else {"type": type(_v).__name__, "size": len(_v)}
                    if isinstance(_v, (list, tuple, set, frozenset))
                    else {"type": type(_v).__name__}
                )
                for _k, _v in locals().items()
                if _k not in {"self", "cls", "_analytics_logger", "_analytics_class_name", "_analytics_args"}
                and not _k.startswith("_analytics")
            }
            _analytics_logger.debug("%s.%s entered | args=%s", _analytics_class_name, "get_stats", _analytics_args)
        except Exception:
            pass
        uptime_seconds = (
            max(0.0, (utc_now() - ensure_utc(self._started_at)).total_seconds())
            if self._started_at
            else 0.0
        )
        return {
            "service_name": self.service_name,
            "input_topics": list(self.config.input_topics),
            "running": self._running,
            "registered": self._registered,
            "closed": self._closed,
            "scope": "exchange:market_type:symbol:timeframe",
            "symbols_filter": list(self.config.symbols),
            "exchanges_filter": list(self.config.exchanges),
            "market_types_filter": list(self.config.market_types),
            "timeframes_filter": list(self.config.timeframes),
            "uptime_seconds": uptime_seconds,
            "processed_messages": self._processed_messages,
            "processed_events": self._processed_events,
            "dropped_invalid": self._dropped_invalid,
            "dropped_stale": self._dropped_stale,
            "dropped_duplicates": self._dropped_duplicates,
            "filtered_scope": self._filtered_scope,
            "storage_errors": self._storage_errors,
            "published_raw": self._published_raw,
            "published_normalized": self._published_normalized,
            "published_large": self._published_large,
            "published_updated": self._published_updated,
            "published_health": self._published_health,
            "published_snapshots": self._published_snapshots,
            "input_mode": "market_state" if self.market_state_store is not None else "event_bus_legacy",
            "processed_snapshot_scopes": self._processed_snapshot_scopes,
            "processed_snapshot_liquidations": self._processed_snapshot_liquidations,
            "last_message_at": self._last_message_at.isoformat() if self._last_message_at else None,
            "last_event_at": self._last_event_at.isoformat() if self._last_event_at else None,
            "last_error": self._last_error,
            "last_error_at": self._last_error_at.isoformat() if self._last_error_at else None,
            "tracked_scopes": self.state.scopes_count,
            "tracked_symbols": self.state.symbols_count,
            "state_total_buffered_events": self.state.total_buffered_events,
            "state_total_events_seen": self.state.total_events_seen,
            "large_events_buffered": len(self._recent_large_events),
            "healthcheck_job_id": self._healthcheck_job_id,
            "snapshot_job_id": self._snapshot_job_id,
            "cleanup_job_id": self._cleanup_job_id,
        }

    def get_health(self) -> dict[str, Any]:
        try:
            _analytics_logger = getattr(self, "logger", None) or getattr(self, "_logger", None)
            if _analytics_logger is None:
                _analytics_logger = get_logger(f"{__name__}.{self.__class__.__name__}")
                self.logger = _analytics_logger
            _analytics_class_name = self.__class__.__name__
            _analytics_args = {
                _k: (
                    {"type": "dict", "size": len(_v), "keys": [str(_key) for _key in list(_v.keys())[:20]]}
                    if isinstance(_v, dict)
                    else {"type": type(_v).__name__, "size": len(_v)}
                    if isinstance(_v, (list, tuple, set, frozenset))
                    else {"type": type(_v).__name__}
                )
                for _k, _v in locals().items()
                if _k not in {"self", "cls", "_analytics_logger", "_analytics_class_name", "_analytics_args"}
                and not _k.startswith("_analytics")
            }
            _analytics_logger.debug("%s.%s entered | args=%s", _analytics_class_name, "get_health", _analytics_args)
        except Exception:
            pass
        return self.estimate_ingestion_health()

    def estimate_ingestion_health(self) -> dict[str, Any]:
        try:
            _analytics_logger = getattr(self, "logger", None) or getattr(self, "_logger", None)
            if _analytics_logger is None:
                _analytics_logger = get_logger(f"{__name__}.{self.__class__.__name__}")
                self.logger = _analytics_logger
            _analytics_class_name = self.__class__.__name__
            _analytics_args = {
                _k: (
                    {"type": "dict", "size": len(_v), "keys": [str(_key) for _key in list(_v.keys())[:20]]}
                    if isinstance(_v, dict)
                    else {"type": type(_v).__name__, "size": len(_v)}
                    if isinstance(_v, (list, tuple, set, frozenset))
                    else {"type": type(_v).__name__}
                )
                for _k, _v in locals().items()
                if _k not in {"self", "cls", "_analytics_logger", "_analytics_class_name", "_analytics_args"}
                and not _k.startswith("_analytics")
            }
            _analytics_logger.debug("%s.%s entered | args=%s", _analytics_class_name, "estimate_ingestion_health", _analytics_args)
        except Exception:
            pass
        now = utc_now()
        if not self._running:
            status = "stopped"
        elif self._last_message_at is None:
            status = "starting"
        else:
            age = (now - ensure_utc(self._last_message_at)).total_seconds()
            degraded_after = max(30.0, self.config.stale_event_threshold_seconds * 2.0)
            status = "healthy" if age <= degraded_after else "degraded"

        return {
            "service": self.service_name,
            "status": status,
            "running": self._running,
            "registered": self._registered,
            "scope": "exchange:market_type:symbol:timeframe",
            "input_topics": list(self.config.input_topics),
            "last_message_at": self._last_message_at.isoformat() if self._last_message_at else None,
            "last_event_at": self._last_event_at.isoformat() if self._last_event_at else None,
            "last_error": self._last_error,
            "last_error_at": self._last_error_at.isoformat() if self._last_error_at else None,
            "processed_messages": self._processed_messages,
            "processed_events": self._processed_events,
            "dropped_invalid": self._dropped_invalid,
            "dropped_stale": self._dropped_stale,
            "dropped_duplicates": self._dropped_duplicates,
            "filtered_scope": self._filtered_scope,
        }

    # ------------------------------------------------------------------
    # Scheduler jobs
    # ------------------------------------------------------------------

    def _register_scheduler_jobs(self) -> None:
        try:
            _analytics_logger = getattr(self, "logger", None) or getattr(self, "_logger", None)
            if _analytics_logger is None:
                _analytics_logger = get_logger(f"{__name__}.{self.__class__.__name__}")
                self.logger = _analytics_logger
            _analytics_class_name = self.__class__.__name__
            _analytics_args = {
                _k: (
                    {"type": "dict", "size": len(_v), "keys": [str(_key) for _key in list(_v.keys())[:20]]}
                    if isinstance(_v, dict)
                    else {"type": type(_v).__name__, "size": len(_v)}
                    if isinstance(_v, (list, tuple, set, frozenset))
                    else {"type": type(_v).__name__}
                )
                for _k, _v in locals().items()
                if _k not in {"self", "cls", "_analytics_logger", "_analytics_class_name", "_analytics_args"}
                and not _k.startswith("_analytics")
            }
            _analytics_logger.debug("%s.%s entered | args=%s", _analytics_class_name, "_register_scheduler_jobs", _analytics_args)
        except Exception:
            pass
        if self.scheduler is None:
            return

        job_suffix = self.service_name

        if self._healthcheck_job_id is None:
            self._healthcheck_job_id = self._add_interval_job_once(
                name=f"{self.config.healthcheck_job_name}:{job_suffix}",
                func=self._scheduled_healthcheck,
                interval=self.config.healthcheck_interval_seconds,
            )

        if self._snapshot_job_id is None:
            self._snapshot_job_id = self._add_interval_job_once(
                name=f"{self.config.snapshot_job_name}:{job_suffix}",
                func=self._scheduled_snapshot,
                interval=self.config.snapshot_interval_seconds,
            )

        if self._cleanup_job_id is None:
            self._cleanup_job_id = self._add_interval_job_once(
                name=f"{self.config.cleanup_job_name}:{job_suffix}",
                func=self._scheduled_cleanup,
                interval=self.config.cleanup_interval_seconds,
            )

    def _add_interval_job_once(
        self,
        *,
        name: str,
        func: Any,
        interval: float,
    ) -> str:
        try:
            _analytics_logger = getattr(self, "logger", None) or getattr(self, "_logger", None)
            if _analytics_logger is None:
                _analytics_logger = get_logger(f"{__name__}.{self.__class__.__name__}")
                self.logger = _analytics_logger
            _analytics_class_name = self.__class__.__name__
            _analytics_args = {
                _k: (
                    {"type": "dict", "size": len(_v), "keys": [str(_key) for _key in list(_v.keys())[:20]]}
                    if isinstance(_v, dict)
                    else {"type": type(_v).__name__, "size": len(_v)}
                    if isinstance(_v, (list, tuple, set, frozenset))
                    else {"type": type(_v).__name__}
                )
                for _k, _v in locals().items()
                if _k not in {"self", "cls", "_analytics_logger", "_analytics_class_name", "_analytics_args"}
                and not _k.startswith("_analytics")
            }
            _analytics_logger.debug("%s.%s entered | args=%s", _analytics_class_name, "_add_interval_job_once", _analytics_args)
        except Exception:
            pass
        assert self.scheduler is not None

        existing_job = self.scheduler.get_job_by_name(name)
        if existing_job is not None:
            return existing_job.job_id

        return self.scheduler.add_interval_job(
            name=name,
            func=func,
            interval=interval,
            run_immediately=False,
            max_retries=self.config.scheduler_job_max_retries,
            retry_delay=self.config.scheduler_job_retry_delay_seconds,
            timeout=self.config.scheduler_job_timeout_seconds,
            allow_overlap=False,
            enabled=True,
        )

    async def _remove_scheduler_jobs(self) -> None:
        try:
            _analytics_logger = getattr(self, "logger", None) or getattr(self, "_logger", None)
            if _analytics_logger is None:
                _analytics_logger = get_logger(f"{__name__}.{self.__class__.__name__}")
                self.logger = _analytics_logger
            _analytics_class_name = self.__class__.__name__
            _analytics_args = {
                _k: (
                    {"type": "dict", "size": len(_v), "keys": [str(_key) for _key in list(_v.keys())[:20]]}
                    if isinstance(_v, dict)
                    else {"type": type(_v).__name__, "size": len(_v)}
                    if isinstance(_v, (list, tuple, set, frozenset))
                    else {"type": type(_v).__name__}
                )
                for _k, _v in locals().items()
                if _k not in {"self", "cls", "_analytics_logger", "_analytics_class_name", "_analytics_args"}
                and not _k.startswith("_analytics")
            }
            _analytics_logger.debug("%s.%s entered | args=%s", _analytics_class_name, "_remove_scheduler_jobs", _analytics_args)
        except Exception:
            pass
        if self.scheduler is None:
            self._healthcheck_job_id = None
            self._snapshot_job_id = None
            self._cleanup_job_id = None
            return

        for job_id in (
            self._healthcheck_job_id,
            self._snapshot_job_id,
            self._cleanup_job_id,
        ):
            if job_id is None:
                continue

            try:
                result = self.scheduler.remove_job(job_id)
                if inspect.isawaitable(result):
                    await result
            except Exception as exc:
                self.logger.warning(
                    "Failed to remove LiquidationStream scheduler job | job_id=%s error=%s",
                    job_id,
                    repr(exc),
                )

        self._healthcheck_job_id = None
        self._snapshot_job_id = None
        self._cleanup_job_id = None

    async def _scheduled_healthcheck(self) -> None:
        try:
            _analytics_logger = getattr(self, "logger", None) or getattr(self, "_logger", None)
            if _analytics_logger is None:
                _analytics_logger = get_logger(f"{__name__}.{self.__class__.__name__}")
                self.logger = _analytics_logger
            _analytics_class_name = self.__class__.__name__
            _analytics_args = {
                _k: (
                    {"type": "dict", "size": len(_v), "keys": [str(_key) for _key in list(_v.keys())[:20]]}
                    if isinstance(_v, dict)
                    else {"type": type(_v).__name__, "size": len(_v)}
                    if isinstance(_v, (list, tuple, set, frozenset))
                    else {"type": type(_v).__name__}
                )
                for _k, _v in locals().items()
                if _k not in {"self", "cls", "_analytics_logger", "_analytics_class_name", "_analytics_args"}
                and not _k.startswith("_analytics")
            }
            _analytics_logger.debug("%s.%s entered | args=%s", _analytics_class_name, "_scheduled_healthcheck", _analytics_args)
        except Exception:
            pass
        health = self.estimate_ingestion_health()
        await self.emit_health()

        if health["status"] == "degraded":
            self.logger.warning("LiquidationStream health degraded | health=%s", health)

    async def _scheduled_snapshot(self) -> None:
        try:
            _analytics_logger = getattr(self, "logger", None) or getattr(self, "_logger", None)
            if _analytics_logger is None:
                _analytics_logger = get_logger(f"{__name__}.{self.__class__.__name__}")
                self.logger = _analytics_logger
            _analytics_class_name = self.__class__.__name__
            _analytics_args = {
                _k: (
                    {"type": "dict", "size": len(_v), "keys": [str(_key) for _key in list(_v.keys())[:20]]}
                    if isinstance(_v, dict)
                    else {"type": type(_v).__name__, "size": len(_v)}
                    if isinstance(_v, (list, tuple, set, frozenset))
                    else {"type": type(_v).__name__}
                )
                for _k, _v in locals().items()
                if _k not in {"self", "cls", "_analytics_logger", "_analytics_class_name", "_analytics_args"}
                and not _k.startswith("_analytics")
            }
            _analytics_logger.debug("%s.%s entered | args=%s", _analytics_class_name, "_scheduled_snapshot", _analytics_args)
        except Exception:
            pass
        await self.emit_runtime_snapshot()
        if self.history_store is not None:
            await self._flush_history_store()

    async def _scheduled_cleanup(self) -> None:
        try:
            _analytics_logger = getattr(self, "logger", None) or getattr(self, "_logger", None)
            if _analytics_logger is None:
                _analytics_logger = get_logger(f"{__name__}.{self.__class__.__name__}")
                self.logger = _analytics_logger
            _analytics_class_name = self.__class__.__name__
            _analytics_args = {
                _k: (
                    {"type": "dict", "size": len(_v), "keys": [str(_key) for _key in list(_v.keys())[:20]]}
                    if isinstance(_v, dict)
                    else {"type": type(_v).__name__, "size": len(_v)}
                    if isinstance(_v, (list, tuple, set, frozenset))
                    else {"type": type(_v).__name__}
                )
                for _k, _v in locals().items()
                if _k not in {"self", "cls", "_analytics_logger", "_analytics_class_name", "_analytics_args"}
                and not _k.startswith("_analytics")
            }
            _analytics_logger.debug("%s.%s entered | args=%s", _analytics_class_name, "_scheduled_cleanup", _analytics_args)
        except Exception:
            pass
        min_timestamp = utc_now() - timedelta(
            seconds=max(
                self.config.stale_event_threshold_seconds,
                int(self.config.cleanup_interval_seconds),
            )
        )
        removed_events = self.state.prune_before(min_timestamp)
        removed_empty_states = self.state.remove_empty()

        if removed_events or removed_empty_states:
            self.logger.info(
                "LiquidationStream cleanup completed | removed_events=%s removed_empty_states=%s",
                removed_events,
                removed_empty_states,
            )

    # ------------------------------------------------------------------
    # Dedup helpers
    # ------------------------------------------------------------------

    def _make_payload_fingerprint(self, payload: dict[str, Any]) -> str:
        try:
            _analytics_logger = getattr(self, "logger", None) or getattr(self, "_logger", None)
            if _analytics_logger is None:
                _analytics_logger = get_logger(f"{__name__}.{self.__class__.__name__}")
                self.logger = _analytics_logger
            _analytics_class_name = self.__class__.__name__
            _analytics_args = {
                _k: (
                    {"type": "dict", "size": len(_v), "keys": [str(_key) for _key in list(_v.keys())[:20]]}
                    if isinstance(_v, dict)
                    else {"type": type(_v).__name__, "size": len(_v)}
                    if isinstance(_v, (list, tuple, set, frozenset))
                    else {"type": type(_v).__name__}
                )
                for _k, _v in locals().items()
                if _k not in {"self", "cls", "_analytics_logger", "_analytics_class_name", "_analytics_args"}
                and not _k.startswith("_analytics")
            }
            _analytics_logger.debug("%s.%s entered | args=%s", _analytics_class_name, "_make_payload_fingerprint", _analytics_args)
        except Exception:
            pass
        stable_parts = [
            self._extract_exchange(payload),
            self._extract_market_type(payload),
            self._extract_symbol(payload),
            self._extract_timeframe(payload),
            self._extract_exchange_symbol(payload, fallback_symbol=self._extract_symbol(payload) or ""),
            self._extract_side(payload).value,
            str(self._extract_price(payload)),
            str(self._extract_quantity(payload)),
            str(
                self._extract_notional(
                    payload,
                    price=self._extract_price(payload),
                    quantity=self._extract_quantity(payload),
                )
            ),
            str(self._extract_timestamp(payload).timestamp()),
            self._extract_trade_id(payload) or "",
            self._extract_order_id(payload) or "",
            self._extract_event_id(payload) or "",
        ]
        return hashlib.sha256("|".join(stable_parts).encode("utf-8")).hexdigest()

    def _is_duplicate_payload_fingerprint(self, fingerprint: str) -> bool:
        try:
            _analytics_logger = getattr(self, "logger", None) or getattr(self, "_logger", None)
            if _analytics_logger is None:
                _analytics_logger = get_logger(f"{__name__}.{self.__class__.__name__}")
                self.logger = _analytics_logger
            _analytics_class_name = self.__class__.__name__
            _analytics_args = {
                _k: (
                    {"type": "dict", "size": len(_v), "keys": [str(_key) for _key in list(_v.keys())[:20]]}
                    if isinstance(_v, dict)
                    else {"type": type(_v).__name__, "size": len(_v)}
                    if isinstance(_v, (list, tuple, set, frozenset))
                    else {"type": type(_v).__name__}
                )
                for _k, _v in locals().items()
                if _k not in {"self", "cls", "_analytics_logger", "_analytics_class_name", "_analytics_args"}
                and not _k.startswith("_analytics")
            }
            _analytics_logger.debug("%s.%s entered | args=%s", _analytics_class_name, "_is_duplicate_payload_fingerprint", _analytics_args)
        except Exception:
            pass
        return fingerprint in self._recent_payload_fingerprint_set

    def _remember_payload_fingerprint(self, fingerprint: str) -> None:
        try:
            _analytics_logger = getattr(self, "logger", None) or getattr(self, "_logger", None)
            if _analytics_logger is None:
                _analytics_logger = get_logger(f"{__name__}.{self.__class__.__name__}")
                self.logger = _analytics_logger
            _analytics_class_name = self.__class__.__name__
            _analytics_args = {
                _k: (
                    {"type": "dict", "size": len(_v), "keys": [str(_key) for _key in list(_v.keys())[:20]]}
                    if isinstance(_v, dict)
                    else {"type": type(_v).__name__, "size": len(_v)}
                    if isinstance(_v, (list, tuple, set, frozenset))
                    else {"type": type(_v).__name__}
                )
                for _k, _v in locals().items()
                if _k not in {"self", "cls", "_analytics_logger", "_analytics_class_name", "_analytics_args"}
                and not _k.startswith("_analytics")
            }
            _analytics_logger.debug("%s.%s entered | args=%s", _analytics_class_name, "_remember_payload_fingerprint", _analytics_args)
        except Exception:
            pass
        if len(self._recent_payload_fingerprints) == self._recent_payload_fingerprints.maxlen:
            oldest = self._recent_payload_fingerprints.popleft()
            self._recent_payload_fingerprint_set.discard(oldest)

        self._recent_payload_fingerprints.append(fingerprint)
        self._recent_payload_fingerprint_set.add(fingerprint)

    # ------------------------------------------------------------------
    # Header / misc helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _headers_for_event(
        event: LiquidationEvent,
        *,
        event_type: LiquidationEventType,
        extra: dict[str, str] | None = None,
    ) -> dict[str, str]:
        try:
            _analytics_class_name = "LiquidationStream"
            _analytics_logger = get_logger(f"{__name__}.{_analytics_class_name}")
            _analytics_args = {
                _k: (
                    {"type": "dict", "size": len(_v), "keys": [str(_key) for _key in list(_v.keys())[:20]]}
                    if isinstance(_v, dict)
                    else {"type": type(_v).__name__, "size": len(_v)}
                    if isinstance(_v, (list, tuple, set, frozenset))
                    else {"type": type(_v).__name__}
                )
                for _k, _v in locals().items()
                if _k not in {"self", "cls", "_analytics_logger", "_analytics_class_name", "_analytics_args"}
                and not _k.startswith("_analytics")
            }
            _analytics_logger.debug("%s.%s entered | args=%s", _analytics_class_name, "_headers_for_event", _analytics_args)
        except Exception:
            pass
        headers = {
            "exchange": event.exchange,
            "market_type": event.market_type,
            "symbol": event.symbol,
            "timeframe": event.timeframe,
            "exchange_symbol": event.exchange_symbol or event.symbol,
            "scope": scoped_key_to_string(event.key),
            "event_type": event_type.value,
        }

        if extra:
            headers.update(extra)

        return headers

    @property
    def is_running(self) -> bool:
        try:
            _analytics_logger = getattr(self, "logger", None) or getattr(self, "_logger", None)
            if _analytics_logger is None:
                _analytics_logger = get_logger(f"{__name__}.{self.__class__.__name__}")
                self.logger = _analytics_logger
            _analytics_class_name = self.__class__.__name__
            _analytics_args = {
                _k: (
                    {"type": "dict", "size": len(_v), "keys": [str(_key) for _key in list(_v.keys())[:20]]}
                    if isinstance(_v, dict)
                    else {"type": type(_v).__name__, "size": len(_v)}
                    if isinstance(_v, (list, tuple, set, frozenset))
                    else {"type": type(_v).__name__}
                )
                for _k, _v in locals().items()
                if _k not in {"self", "cls", "_analytics_logger", "_analytics_class_name", "_analytics_args"}
                and not _k.startswith("_analytics")
            }
            _analytics_logger.debug("%s.%s entered | args=%s", _analytics_class_name, "is_running", _analytics_args)
        except Exception:
            pass
        return self._running

    @property
    def is_connected(self) -> bool:
        # EventBus consumer has no exchange socket connection of its own.
        try:
            _analytics_logger = getattr(self, "logger", None) or getattr(self, "_logger", None)
            if _analytics_logger is None:
                _analytics_logger = get_logger(f"{__name__}.{self.__class__.__name__}")
                self.logger = _analytics_logger
            _analytics_class_name = self.__class__.__name__
            _analytics_args = {
                _k: (
                    {"type": "dict", "size": len(_v), "keys": [str(_key) for _key in list(_v.keys())[:20]]}
                    if isinstance(_v, dict)
                    else {"type": type(_v).__name__, "size": len(_v)}
                    if isinstance(_v, (list, tuple, set, frozenset))
                    else {"type": type(_v).__name__}
                )
                for _k, _v in locals().items()
                if _k not in {"self", "cls", "_analytics_logger", "_analytics_class_name", "_analytics_args"}
                and not _k.startswith("_analytics")
            }
            _analytics_logger.debug("%s.%s entered | args=%s", _analytics_class_name, "is_connected", _analytics_args)
        except Exception:
            pass
        return self._running and self._registered

    @property
    def is_closed(self) -> bool:
        try:
            _analytics_logger = getattr(self, "logger", None) or getattr(self, "_logger", None)
            if _analytics_logger is None:
                _analytics_logger = get_logger(f"{__name__}.{self.__class__.__name__}")
                self.logger = _analytics_logger
            _analytics_class_name = self.__class__.__name__
            _analytics_args = {
                _k: (
                    {"type": "dict", "size": len(_v), "keys": [str(_key) for _key in list(_v.keys())[:20]]}
                    if isinstance(_v, dict)
                    else {"type": type(_v).__name__, "size": len(_v)}
                    if isinstance(_v, (list, tuple, set, frozenset))
                    else {"type": type(_v).__name__}
                )
                for _k, _v in locals().items()
                if _k not in {"self", "cls", "_analytics_logger", "_analytics_class_name", "_analytics_args"}
                and not _k.startswith("_analytics")
            }
            _analytics_logger.debug("%s.%s entered | args=%s", _analytics_class_name, "is_closed", _analytics_args)
        except Exception:
            pass
        return self._closed

    def _safe_payload_preview(
        self,
        payload: dict[str, Any],
        max_len: int = 1000,
    ) -> str:
        try:
            _analytics_logger = getattr(self, "logger", None) or getattr(self, "_logger", None)
            if _analytics_logger is None:
                _analytics_logger = get_logger(f"{__name__}.{self.__class__.__name__}")
                self.logger = _analytics_logger
            _analytics_class_name = self.__class__.__name__
            _analytics_args = {
                _k: (
                    {"type": "dict", "size": len(_v), "keys": [str(_key) for _key in list(_v.keys())[:20]]}
                    if isinstance(_v, dict)
                    else {"type": type(_v).__name__, "size": len(_v)}
                    if isinstance(_v, (list, tuple, set, frozenset))
                    else {"type": type(_v).__name__}
                )
                for _k, _v in locals().items()
                if _k not in {"self", "cls", "_analytics_logger", "_analytics_class_name", "_analytics_args"}
                and not _k.startswith("_analytics")
            }
            _analytics_logger.debug("%s.%s entered | args=%s", _analytics_class_name, "_safe_payload_preview", _analytics_args)
        except Exception:
            pass
        text = repr(payload)
        return text if len(text) <= max_len else text[:max_len] + "...<truncated>"


__all__ = [
    "LiquidationHistoryStoreProtocol",
    "LiquidationStream",
]
